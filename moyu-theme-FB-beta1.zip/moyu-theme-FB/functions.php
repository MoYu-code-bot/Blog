<?php

if (!defined('ABSPATH')) {
    exit;
}

function moyu_glass_setup(): void
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
}
add_action('after_setup_theme', 'moyu_glass_setup');

function moyu_glass_assets(): void
{
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('dashicons');
    wp_enqueue_style('moyu-glass', get_stylesheet_uri(), [], $version);
    $background = get_theme_mod('moyu_background_image', get_theme_file_uri('assets/images/sunset-hero.png'));
    wp_add_inline_style('moyu-glass', ':root{--moyu-background-image:url(' . wp_json_encode(esc_url_raw($background)) . ');}');
    wp_enqueue_script('moyu-glass-intro', get_theme_file_uri('assets/js/intro.js'), [], $version, true);
    wp_enqueue_script('moyu-glass-glow', get_theme_file_uri('assets/js/mouse-glow.js'), [], $version, true);
    wp_enqueue_script('moyu-glass-navigation', get_theme_file_uri('assets/js/navigation.js'), [], $version, true);
}
add_action('wp_enqueue_scripts', 'moyu_glass_assets');

function moyu_glass_intro_boot(): void
{
    ?>
    <script>
    try {
        if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches && sessionStorage.getItem('moyu-glass-intro-seen') !== '1') {
            document.documentElement.classList.add('moyu-intro-enabled');
        }
    } catch (error) {
        document.documentElement.classList.add('moyu-intro-enabled');
    }
    </script>
    <?php
}
add_action('wp_head', 'moyu_glass_intro_boot', 1);

function moyu_glass_intro(): void
{
    ?>
    <div class="moyu-intro" id="moyu-intro" aria-label="网站入场动画">
        <div class="moyu-intro-scene" aria-hidden="true"></div>
        <img class="moyu-intro-ring" src="<?php echo esc_url(get_theme_file_uri('assets/images/intro-ink-ring.png')); ?>" alt="">
        <p class="moyu-intro-title" aria-hidden="true">墨雨</p>
        <button class="moyu-intro-skip" type="button">跳过</button>
    </div>
    <?php
}
add_action('wp_body_open', 'moyu_glass_intro');

function moyu_glass_articles_url(): string
{
    $page_id = (int) get_option('page_for_posts');
    return $page_id ? get_permalink($page_id) : home_url('/?post_type=post');
}

function moyu_glass_about_url(): string
{
    $page = get_page_by_path('about');
    return $page ? get_permalink($page) : home_url('/about/');
}

function moyu_glass_hubs(): array
{
    return [
        'technical-notes' => ['title' => '技术笔记', 'description' => '记录编程实践、工具使用与技术成长。', 'category' => '技术笔记'],
        'ai-exploration' => ['title' => 'AI 探索', 'description' => '关注人工智能的发展、工具与实际应用。', 'category' => 'AI 探索'],
        'site-building' => ['title' => '建站记录', 'description' => '整理从域名、服务器到 WordPress 的建站过程。', 'category' => '建站记录'],
        'life-essays' => ['title' => '生活随笔', 'description' => '收藏生活片段、阅读感想与日常思考。', 'category' => '生活随笔'],
        'community' => ['title' => '社区', 'description' => '交流与分享空间正在建设中，后续将在这里添加互动功能。', 'category' => ''],
    ];
}

function moyu_glass_hub_url(string $slug): string
{
    $page = get_page_by_path($slug, OBJECT, 'page');
    return $page ? get_permalink($page) : home_url('/' . $slug . '/');
}

function moyu_glass_ensure_hub_pages(): void
{
    if (!current_user_can('manage_options') || get_option('moyu_glass_hub_pages_version') === '1.20.0') {
        return;
    }

    foreach (moyu_glass_hubs() as $slug => $hub) {
        if ($hub['category'] && !term_exists($hub['category'], 'category')) {
            wp_insert_term($hub['category'], 'category');
        }

        $page = get_page_by_path($slug, OBJECT, 'page');
        $page_id = $page ? $page->ID : wp_insert_post([
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_title' => $hub['title'],
            'post_name' => $slug,
            'post_content' => $hub['description'],
        ]);

        if (is_wp_error($page_id) || !$page_id) {
            return;
        }

        if ($page && $page->post_status !== 'publish') {
            wp_update_post(['ID' => $page_id, 'post_status' => 'publish']);
        }

        update_post_meta((int) $page_id, '_wp_page_template', 'page-content-hub.php');
    }

    update_option('moyu_glass_hub_pages_version', '1.20.0', false);
}
add_action('admin_init', 'moyu_glass_ensure_hub_pages');

function moyu_glass_archive_size(WP_Query $query): void
{
    if (is_admin() || !$query->is_main_query()) {
        return;
    }

    if ($query->is_search()) {
        $query->set('post_type', 'post');
    }

    if ($query->is_home() || $query->is_archive() || $query->is_search()) {
        $query->set('posts_per_page', 10);
    }
}
add_action('pre_get_posts', 'moyu_glass_archive_size');

function moyu_glass_count_page_view(): void
{
    if (is_admin() || is_preview() || is_feed() || wp_doing_ajax() || wp_doing_cron() || current_user_can('manage_options')) {
        return;
    }

    update_option('moyu_glass_page_views', (int) get_option('moyu_glass_page_views', 0) + 1, false);
}
add_action('template_redirect', 'moyu_glass_count_page_view');

function moyu_glass_reading_minutes(?int $post_id = null): int
{
    $content = wp_strip_all_tags(get_post_field('post_content', $post_id ?: get_the_ID()));
    preg_match_all('/[\p{Han}]|[A-Za-z0-9]+/u', $content, $matches);
    return max(1, (int) ceil(count($matches[0]) / 300));
}

function moyu_glass_customize(WP_Customize_Manager $customizer): void
{
    $customizer->add_section('moyu_appearance', [
        'title' => 'MY Blog 外观',
        'priority' => 29,
    ]);
    $customizer->add_setting('moyu_background_image', [
        'default' => get_theme_file_uri('assets/images/sunset-hero.png'),
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $customizer->add_control(new WP_Customize_Image_Control($customizer, 'moyu_background_image', [
        'section' => 'moyu_appearance',
        'label' => '网站背景图片',
        'description' => '用于首页、文章页和关于页面的全站背景。',
    ]));

    $customizer->add_section('moyu_profile', [
        'title' => 'MY Blog 左侧栏',
        'priority' => 30,
    ]);

    $fields = [
        'moyu_brand' => ['顶部名称', 'MY Blog'],
        'moyu_profile_name' => ['个人名称', '你好，我是墨雨'],
        'moyu_profile_intro' => ['个人简介', '记录技术、生活与持续成长'],
        'moyu_skills_title' => ['技能标题', '我擅长的事'],
        'moyu_skill_1' => ['技能一', '技术写作'],
        'moyu_skill_2' => ['技能二', '网站开发'],
        'moyu_skill_3' => ['技能三', '持续学习'],
        'moyu_skill_4' => ['技能四', '经验分享'],
        'moyu_stats_title' => ['统计标题', '站点统计'],
        'moyu_tags_title' => ['标签标题', '标签'],
        'moyu_updated_title' => ['更新标题', '最近更新'],
    ];

    foreach ($fields as $id => [$label, $default]) {
        $customizer->add_setting($id, ['default' => $default, 'sanitize_callback' => 'sanitize_text_field']);
        $customizer->add_control($id, ['section' => 'moyu_profile', 'label' => $label, 'type' => 'text']);
    }

    $customizer->add_setting('moyu_personal_tags', ['default' => '', 'sanitize_callback' => 'sanitize_textarea_field']);
    $customizer->add_control('moyu_personal_tags', [
        'section' => 'moyu_profile',
        'label' => '个人标签',
        'description' => '使用逗号、中文逗号或换行分隔，可添加多个标签。',
        'type' => 'textarea',
    ]);

    $customizer->add_setting('moyu_profile_avatar', [
        'default' => get_theme_file_uri('assets/images/avatar.png'),
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $customizer->add_control(new WP_Customize_Image_Control($customizer, 'moyu_profile_avatar', [
        'section' => 'moyu_profile',
        'label' => '个人头像',
    ]));

    foreach (['moyu_profile_site' => '个人网站链接', 'moyu_profile_github' => 'GitHub 链接'] as $id => $label) {
        $customizer->add_setting($id, ['default' => '', 'sanitize_callback' => 'esc_url_raw']);
        $customizer->add_control($id, ['section' => 'moyu_profile', 'label' => $label, 'type' => 'url']);
    }

    $customizer->add_section('moyu_footer', [
        'title' => 'MY Blog 页脚',
        'priority' => 31,
    ]);
    foreach ([
        'moyu_footer_copyright' => ['版权文字', '©2026墨雨的博客网站'],
        'moyu_footer_slogan' => ['页脚文案', 'Stay curious, keep learning, and grow a little every day.'],
    ] as $id => [$label, $default]) {
        $customizer->add_setting($id, ['default' => $default, 'sanitize_callback' => 'sanitize_text_field']);
        $customizer->add_control($id, ['section' => 'moyu_footer', 'label' => $label, 'type' => 'text']);
    }

}
add_action('customize_register', 'moyu_glass_customize');
